nmcli con modify enp193s0f0 ipv6.method manual
nmcli con modify enp193s0f0 ipv6.addresses 2606:69c0:9120:782a:20a:f7ff:fe5b:eee0/64
nmcli con modify enp193s0f0 ipv6.gateway fe80::a43f:68ff:fecd:8355
nmcli con modify enp193s0f0 ipv6.dns "2606:69c0:5120:5020::7 2606:69c0:5120:5020::8 2606:69c0:9120:5020::7 2606:69c0:9120:5020::8"
nmcli con modify enp193s0f0 ipv6.addr-gen-mode stable-privacy
nmcli con modify enp193s0f0 ipv6.ip6-privacy 0
nmcli con down enp193s0f0 && nmcli con up enp193s0f0

