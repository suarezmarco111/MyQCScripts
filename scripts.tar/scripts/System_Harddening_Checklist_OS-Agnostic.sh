#!/usr/bin/env bash

# system_check.sh - Validates system hardening and configuration steps
# Author: MarcoAntonio & ChatGPT

# OS Detection
if [ -f /etc/os-release ]; then
    . /etc/os-release
    OS_FAMILY=$ID
else
    OS_FAMILY="unknown"
fi

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
NC='\033[0m' # No Color

REPORT="/tmp/system_hardening_report.txt"
HTML_REPORT="/tmp/system_hardening_report.html"
FAILED=0

clear
cat << "EOF"
  ____            _                 _                 _           _         
 / ___| _   _ ___| |_ ___ _ __ ___(_)_ __   __ _    / \   _ __  | |_  ___  
 \___ \| | | / __| __/ _ \ '__/ __| | '_ \ / _` |  / _ \ | '_ \ | __|/ _ \ 
  ___) | |_| \__ \ ||  __/ | | (__| | | | | (_| | / ___ \| | | || |_| (_) |
 |____/ \__, |___/\__\___|_|  \___|_|_| |_|\__, |/_/   \_\_| |_| \__|\___/ 
        |___/                              |___/                          
EOF

printf "\nSystem Hardening Report - $(hostname) - $(date)\n" > "$REPORT"
echo "========================================================" >> "$REPORT"

echo "<html><body><h2>System Hardening Report - $(hostname)</h2><pre>" > "$HTML_REPORT"
echo "Generated: $(date)" >> "$HTML_REPORT"
echo "========================================================" >> "$HTML_REPORT"

check() {
    echo -n "[+] $1 ... "
    eval "$2" > /dev/null 2>&1
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}OK${NC}"
        if [[ "$1" == "MFA sshd config" ]]; then
            echo "[OK] $1" >> "$REPORT"
            echo "    -> Configured but not enabled. To enable, uncomment AuthenticationMethods in /etc/ssh/sshd_config and set KbdInteractiveAuthentication to yes" >> "$REPORT"
        else
            echo "[OK] $1" >> "$REPORT"
        fi
    else
        echo -e "${RED}FAILED${NC}"
        echo "[FAILED] $1" >> "$REPORT"
        echo "    -> $3" >> "$REPORT"
        FAILED=1
    fi
}

if [[ "$OS_FAMILY" =~ (debian|ubuntu) ]]; then
    check "Chrony Installed" "dpkg -l | grep -qw chrony" "Run: sudo apt install chrony"
elif [[ "$OS_FAMILY" =~ (rhel|centos|rocky|almalinux|fedora) ]]; then
    check "Chrony Installed" "rpm -q chrony" "Run: sudo yum install chrony"
else
    check "Chrony Installed" "false" "Unsupported OS family for package check"
fi
if [[ "$OS_FAMILY" =~ (debian|ubuntu) ]]; then
    check "AppArmor Enabled" "systemctl is-active --quiet apparmor" "Run: sudo apt install apparmor apparmor-utils && sudo systemctl enable --now apparmor"
elif [[ "$OS_FAMILY" =~ (rhel|centos|rocky|almalinux|fedora) ]]; then
    check "AppArmor Enabled" "false" "AppArmor is not supported on $OS_FAMILY; consider checking SELinux status"
else
    check "AppArmor Enabled" "false" "Unsupported OS family for AppArmor check"
fi
check "SSH Public Keys Present" "[ -s ~/.ssh/authorized_keys ]" "Add your public key to ~/.ssh/authorized_keys"
check "Banner Script Present" "[ -x /etc/profile.d/show-banner.sh ] && grep -q 'cat /etc/exx-motd' /etc/profile.d/show-banner.sh" "Run: echo 'cat /etc/exx-motd' | sudo tee /etc/profile.d/show-banner.sh && sudo chmod +x /etc/profile.d/show-banner.sh"
check "Time Zone is EST" "timedatectl | grep -q 'Time zone: America/New_York'" "Run: sudo timedatectl set-timezone America/New_York"
check "sudoers lecture enabled" "grep -q '^Defaults\s\+lecture=always' /etc/sudoers" "Add: Defaults lecture=always to /etc/sudoers"
if [[ "$OS_FAMILY" =~ (debian|ubuntu) ]]; then
    check "Google Authenticator PAM" "test -f /lib/security/pam_google_authenticator.so || test -f /lib/x86_64-linux-gnu/security/pam_google_authenticator.so" "Install: sudo apt install libpam-google-authenticator to ensure the PAM module is available"
elif [[ "$OS_FAMILY" =~ (rhel|centos|rocky|almalinux|fedora) ]]; then
    check "Google Authenticator PAM" "rpm -ql pam_google_authenticator &>/dev/null" "Install: sudo yum install google-authenticator or pam_google_authenticator"
else
    check "Google Authenticator PAM" "false" "Unsupported OS family for PAM module check"
fi
check "MFA sshd config" "grep -Eq '^#?\s*AuthenticationMethods\s+publickey,keyboard-interactive' /etc/ssh/sshd_config" "Add: AuthenticationMethods publickey,keyboard-interactive (uncomment when ready to enforce MFA)"
check "hosts.allow/deny present" "[ -f /etc/hosts.allow ] && [ -f /etc/hosts.deny ]" "Configure /etc/hosts.allow and /etc/hosts.deny for TCP wrappers"
check "quest-vasd present" "systemctl status vasd | grep -q running" "Install VASD from Quest and run join_pegasus_nodes_ead.sh"
check "VAS Joined (vastool status)" "/opt/quest/bin/vastool status | grep -q 'Domain: <ead.gwu.edu>'" "Run: /opt/quest/bin/vastool join to rejoin domain"
check "IPMI LAN config" "ipmitool lan print 1 | grep -q 'IP Address'" "Run IPMI_LAN_CONFIG.sh to set up remote management"
if [[ "$OS_FAMILY" =~ (debian|ubuntu) ]]; then
    check "logwatch configured" "dpkg -l | grep -qw logwatch && [ -f /usr/share/logwatch/default.conf/logwatch.conf ]" "Run: sudo apt install logwatch && configure the logwatch.conf"
elif [[ "$OS_FAMILY" =~ (rhel|centos|rocky|almalinux|fedora) ]]; then
    check "logwatch configured" "rpm -q logwatch && [ -f /usr/share/logwatch/default.conf/logwatch.conf ]" "Run: sudo yum install logwatch && configure the logwatch.conf"
else
    check "logwatch configured" "false" "Unsupported OS family for logwatch check"
fi
check "rsyslog active" "systemctl is-active --quiet rsyslog" "Run: sudo systemctl enable --now rsyslog"
if [[ "$OS_FAMILY" =~ (debian|ubuntu) ]]; then
    check "fail2ban installed" "dpkg -l | grep -qw fail2ban" "Run: sudo apt install fail2ban && enable jail configs"
elif [[ "$OS_FAMILY" =~ (rhel|centos|rocky|almalinux|fedora) ]]; then
    check "fail2ban installed" "rpm -q fail2ban" "Run: sudo yum install fail2ban && enable jail configs"
else
    check "fail2ban installed" "false" "Unsupported OS family for fail2ban check"
fi
check "GWU IPv6 allowlisted in hosts.allow" "grep -q '^ALL: \[2606:69c0::\]/28' /etc/hosts.allow" "Add: echo 'ALL: [2606:69c0::]/28' | sudo tee -a /etc/hosts.allow"
check "Default deny rule in hosts.deny" "grep -q '^ALL : ALL : DENY' /etc/hosts.deny" "Ensure /etc/hosts.deny contains: ALL : ALL : DENY"
check "PARANOID rule in hosts.deny" "grep -q '^ALL : PARANOID' /etc/hosts.deny" "Recommended: Add 'ALL : PARANOID' to block spoofed clients"

# Parse latest CIS-CAT HTML report from /root/Assessor/reports
CIS_DIR="/root/Assessor/reports"
CIS_HTML=$(ls -1t "$CIS_DIR"/*$(hostname)*.html 2>/dev/null | head -n 1)

if [ -n "$CIS_HTML" ] && grep -q 'CIS' "$CIS_HTML"; then
    echo "[OK] CIS-CAT Scan Done" >> "$REPORT"
    echo "[OK] Latest CIS-CAT HTML Report: $(basename "$CIS_HTML")" >> "$REPORT"
else
    echo "[FAILED] CIS-CAT Scan Done" >> "$REPORT"
    echo "    -> No recent CIS-CAT report found in $CIS_DIR for $(hostname)" >> "$REPORT"
    echo "    -> To run manually: /root/Assessor/Assessor-CLI.sh -benchmark \"CIS_Ubuntu_Linux_22.04_LTS\" -profile 2 -html -i" >> "$REPORT"
    FAILED=1
fi

# Output summary
cat "$REPORT"
echo "</pre></body></html>" > "$HTML_REPORT"
echo -e "\n${GREEN}✔ Check completed. Review the report at $REPORT${NC}"

# Optional: Send email if any failures
if [ "$FAILED" -eq 1 ]; then
    # Uncomment and configure below to enable email alert:
    # mail -s "[HARDENING REPORT] Issues on $(hostname)" you@example.com < "$REPORT"
    echo -e "\n${RED}✉ Some checks failed. Consider reviewing and emailing the report.${NC}"
fi

exit 0

