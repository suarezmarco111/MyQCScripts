#!/usr/bin/env bash
timestamp=$(date +"%Y-%m-%d_%H-%M-%S")
output="lynis_scan_$timestamp.txt"

echo "Running Lynis scan. This may take a few minutes..."
lynis audit system --no-colors | tee "$output"
echo "✅ Scan complete. Report saved to: $output"

