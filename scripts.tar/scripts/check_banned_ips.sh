#!/usr/bin/env bash

echo "Checking banned IPv4 and IPv6 addresses from fail2ban..."

# Get list of active jails
jails=$(fail2ban-client status | grep 'Jail list:' | cut -d: -f2 | tr ',' ' ')

# Loop through each jail
for jail in $jails; do
    jail=$(echo "$jail" | xargs)  # trim whitespace
    echo "Jail: $jail"

    # Get list of banned IPs in this jail
    banned_ips=$(fail2ban-client status "$jail" | grep 'Banned IP list:' | cut -d: -f2-)

    # If no IPs, skip
    if [[ -z "$banned_ips" ]]; then
        echo "  No IPs banned."
        continue
    fi

    # Split IPs into IPv4 and IPv6
    ipv4_list=()
    ipv6_list=()
    for ip in $banned_ips; do
        if [[ $ip =~ : ]]; then
            ipv6_list+=("$ip")
        else
            ipv4_list+=("$ip")
        fi
    done

    if [[ ${#ipv4_list[@]} -gt 0 ]]; then
        echo "  Banned IPv4:"
        for ip in "${ipv4_list[@]}"; do
            echo "    $ip"
        done
    fi

    if [[ ${#ipv6_list[@]} -gt 0 ]]; then
        echo "  Banned IPv6:"
        for ip in "${ipv6_list[@]}"; do
            echo "    $ip"
        done
    fi
done

